<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="Kimball Tech offers world class solution and services to all our clients and support services of experienced personal. We offer a dynamic blend of strategy consulting and system integration services to help organizations architect and built their business in the Economical way." />
<meta name="keywords" content="Kimball Tech" />
<link rel="canonical" href="https://kimballtech.com/" />
<link rel="image_src" href="images/socialmedia-image.JPG" />
<meta property="og:title" content="Kimball Tech"/>
<meta property="og:type" content="article"/>
<meta property="og:url" content="https://kimballtech.com/" />
<meta property="og:image" content="images/socialmedia-image.JPG"/>
<meta property="og:site_name" content="Kimball Tech"/>
<meta property="og:description" content="Kimball Tech offers world class solution and services to all our clients and support services of experienced personal. We offer a dynamic blend of strategy consulting and system integration services to help organizations architect and built their business in the Economical way."/>
<meta name="twitter:card" value="summary" />
<meta name="twitter:site" value="@Kimball Tech" />
<meta property="twitter:url" content="https://kimballtech.com/" />
<meta property="twitter:title" content="Kimball Tech"/>
<meta property="twitter:description" content="Kimball Tech offers world class solution and services to all our clients and support services of experienced personal. We offer a dynamic blend of strategy consulting and system integration services to help organizations architect and built their business in the Economical way." />
<title> About | MIVigilance &#8211; Let the eye of vigilance never be closed.</title>
<?php include("includes/links.php"); ?>

</head>
<body>

<style>


   a.about {
    color: #3a84c6 !important;
    
} 



  .thumbnail {
    padding: 0px !important;
    border: none !important;
    border-radius: 0px !important;
    box-shadow: 1px 4px 10px #00000038;
}
.thumbnail a>img, .thumbnail>img {
    margin-right: auto;
    margin-left: auto;
}
.thumbnail {
    display: block;
    margin-bottom: 20px;
    line-height: 1.42857143;
    background-color: #000;

    border-radius: 4px;
    min-height: 350px !important;
	    text-align: center;
}
.thumbnail .caption {
    padding: 9px 12px 28px 14px !important;
    color: #fff;
    min-height: 330px;
}

.thumbnail p {
color: #fff
}

.hd-divder {
    background: #ffa500;
    width: 80px;
    height: 4px;
    margin: 28px 10px 30px 0px;
}
</style>
<?php include("includes/header.php"); ?>




    <!-- Full Screen Search Start -->
    <div class="modal fade" id="searchModal" tabindex="-1">
        <div class="modal-dialog modal-fullscreen">
            <div class="modal-content" style="background: rgba(9, 30, 62, .7);">
                <div class="modal-header border-0">
                    <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body d-flex align-items-center justify-content-center">
                    <div class="input-group" style="max-width: 600px;">
                        <input type="text" class="form-control bg-transparent border-primary p-3" placeholder="Type search keyword">
                        <button class="btn btn-primary px-4"><i class="bi bi-search"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Full Screen Search End -->


    <!-- Hero Start -->
    <div class="container-fluid  py-5 hero-header8 mb-5">
        <div class="cap">
        <div class="row py-3">
            <div class="col-12 text-center">
                <h1 class="display-3 text-white animated zoomIn">About Us</h1>
                <div class="para">
                <p> Let the eye of vigilance never be closed. </p>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- Hero End -->
	

		<!--- About Us 1 Start ----->
	<div class="about-sectiob">
	<div class="container">
	<div class="row">
	<div class="col-md-3">
	<img src="images/about78.jpg" alt="">
	<center><p>We intend to provide our customers with improved development, training, and staffing services.</p></center>
	</div>
	<div class="col-md-3">
	<div class="abtut">
	<img src="images/about79.jpg" alt="">
	<center><p>We believe in a strong relationship with the customer by having a customer is the first philosophy</p></center>
	</div>
	</div>
	<div class="col-md-6">
	<div class="headingibdg">
	<h2>Our Story</h2>
	<p>Pharmacies, biotech firms, manufacturers of medical devices, CROs, hospitals, and patients are among the many of the clients served by MIVigilance, a leading single source provider of compliance, pharmacovigilance, and comprehensive medical information services, including fully integrated 24/7/365 contact centers.</p>
	</div>
	
	</div>
	</div>
	</div>
	</div>

	
	<!--- About Us 1 End ------>		
	
	
	
	<!-- start hero area -->
	
<div class="container">	
	<!--<div class="heading-train">
<h2>IT Solutions, Support and Managed Service Provide</h2>
<p>Kimball Tech has a young, energetic and professional team from Technology, Consulting, Business Management and Client Servicing domains that takes pride in enhancing performance with each day.The team comprises of highly strategic consultants, software developers, mobile developer, web designers and developers, SEO analyst, and online marketing experts to help spearhead your businesses whilst rendering a hi-tech edge to it. We believe in making you grow financially so expect the most professional outcome at an affordable rate.</p>
</div>-->
<div class="row">
<div class="col-md-1">
</div>

<div class="col-md-5">
<div class="missionqw">
<div class="row">
<div class="col-md-5">
<img src="images/about98.jpg" alt="">
</div>
<div class="col-md-7">
<div class="insideohy">
<h3>Vision</h3>
<p>To enhance the health and safety of patients by offering the highest level of clinical, informative and compliance services.</p>
</div>
</div>
</div>
</div>
</div>

<div class="col-md-5">
<div class="missionqw">
<div class="row">
<div class="col-md-5">
<img src="images/about99.jpg" alt="">
</div>
<div class="col-md-7">
<div class="insideohy">
<h3>Mission</h3>
<p>To create new approaches and to lead the world in providing specialized pharmaceutical services that solve unmet medical needs.</p>
</div>
</div>
</div>
</div>
</div>


<div class="col-md-1">
</div>
</div>



<div class="row">
<div class="col-md-1">
</div>


<div class="col-md-1">
</div>
</div>
		
		
		
		</div>
	

	<!-- end hero area -->
	
	
	

	<!-- shop banner -->
	
	<!-- end shop banner -->
	
	
	
	

    
<?php include("includes/footer.php"); ?>
<!----------footer end-------------------->


<?php include("includes/script.php"); ?>
</body>
</html>
    </body>

