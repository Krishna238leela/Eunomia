	<!-- footer -->
	<div class="footer-area">
		<div class="container">
			<div class="row">
			<div class="col-lg-4">
      <div class="widget">
        <div class="lgp">
      <div class="logo2">
<a href="index.php"><img src="images/logo-white.png"></a>
</div>
<p>We offer comprehensive pharmacovigilance services, including adverse event reporting, signal detection and management, risk management planning, and safety database management.</p>
 

    </div>
	<div class="socamedia1">
            <div class="side-menu__social1 ">
                        <a href="https://www.facebook.com/" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        <a href="https://www.linkedin.com/" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        <a href="#" target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
						<a href="#" target="_blank"><i class="fa fa-skype" aria-hidden="true"></i></a>
                        
                    </div>
			</div>
    <!-- /.col-lg-4 -->
  </div>
  </div>
				<div class="col-lg-4 col-md-6">
					<div class="footer-box get-in-touch">
						<h2 class="widget-title">Get in Touch</h2>
						<div class="add">
						<p class="number-website">
						<i class="fa fa-map-marker" aria-hidden="true"></i><a>&nbsp;&nbsp;&nbsp;41 B, Zarina Park,Opp BARC Main Gate<br>&nbsp;&nbsp;&nbsp;&nbsp;Mankhurd, Mumbai 400080</a></p>
						<p class="number-website"><i class="fa fa-envelope" aria-hidden="true"></i>&nbsp;&nbsp;<a>info@eunomia.com</a></p>
						<p class="number-website"><i class="fa fa-phone" aria-hidden="true"></i>&nbsp;&nbsp;<a>+00 111 222 3333</a></p>
					
					</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="footer-box pages">
						<h2 class="widget-title">Quick Links</h2>
						<ul>
							<li><a href="index.php">Home</a></li>
							<li><a href="">About</a></li>
							<li><a href="">Our Services</a></li>
							
							<li><a href="">Contact</a></li>
						</ul>
					</div>
				</div>
				
			</div>
			<div class="footer-legal text-center position-relative">
    <div class="container">
      <div class="copy d-none d-lg-block"></div>
      <div class="col-md-12">
        
    
       
        <center><p> Copyright ©2023 - Eunomia Pharma Services.</p></center>
    
        </div>
    </div>
      
  </div>
		</div>
	</div>
	<!-- end footer -->
	
	<!-- copyright -->

	<!-- end copyright -->