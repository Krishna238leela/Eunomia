<!-- header -->
	<div class="top-header-area" id="sticker">
		<div class="fluid-container">
			<div class="row">
				<div class="col-lg-12 col-sm-12 text-center">
					<div class="main-menu-wrap">
						<!-- logo -->
						<div class="site-logo">
							<a href="index.php">
								<img src="images/logo.png" alt="">
							</a>
						</div>
						<!-- logo -->

						<!-- menu start -->
						<nav class="main-menu">





							<ul>
								<li class=""><a class="index" href="index.php">Home</a>
									
								</li>
								<li><a class="about" href="">About</a></li>
			
								<li><a class="our-services" href="">Our Services</a>
							
								</li>
								
									
								<li><a class="contact" href="">Contact</a></li>
							
							
							</ul>
						</nav>
						
						<div class="mobile-menu"></div>
						<!-- menu end -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- end header -->